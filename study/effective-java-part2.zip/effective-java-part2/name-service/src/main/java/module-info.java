/**
 * name module
 */
module me.whitehip.name {
    exports me.whiteship.name;
}