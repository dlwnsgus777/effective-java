package me.whiteship.name;

public class NameService {

    public String getName() {
        return "whiteship";
    }
}
