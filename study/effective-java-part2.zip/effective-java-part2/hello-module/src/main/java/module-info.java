/**
 * Hello Module
 */
module me.whiteship.hello {
    requires me.whitehip.name;
}