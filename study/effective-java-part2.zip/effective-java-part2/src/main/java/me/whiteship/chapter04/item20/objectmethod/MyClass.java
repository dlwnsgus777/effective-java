package me.whiteship.chapter04.item20.objectmethod;

public class MyClass implements MyInterface {
}
