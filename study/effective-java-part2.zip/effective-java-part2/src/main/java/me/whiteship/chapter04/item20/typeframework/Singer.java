package me.whiteship.chapter04.item20.typeframework;

public interface Singer {

    AudioClip sing(Song song);
}
