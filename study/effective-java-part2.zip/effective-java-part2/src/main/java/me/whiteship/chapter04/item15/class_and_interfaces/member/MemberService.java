package me.whiteship.chapter04.item15.class_and_interfaces.member;

public interface MemberService {
}
