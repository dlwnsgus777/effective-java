package me.whiteship.chapter05.item33.bounded_type_token;

@FindMe
public class MyService {
}
