package me.whiteship.chapter04.item20.multipleinheritance;

public interface Flyable {

    void fly();
}
