package me.whiteship.chapter04.item20.multipleinheritance;

public abstract class AbstractCat {

    protected abstract String sound();

    protected abstract String name();
}
