package me.whiteship.chapter04.item25;

// 코드 25-2 두 클래스가 한 파일(Dessert.java)에 정의되었다. - 따라 하지 말 것! (151쪽)
//class Utensil {
//    static final String NAME = "pot";
//}
//
//class Dessert {
//    static final String NAME = "pie";
//}
