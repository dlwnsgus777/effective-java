package me.whiteship.chapter05.item33.bounded_type_token;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface FindMe {
}
