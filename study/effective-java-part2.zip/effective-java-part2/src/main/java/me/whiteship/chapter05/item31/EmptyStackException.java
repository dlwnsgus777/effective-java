package me.whiteship.chapter05.item31;

public class EmptyStackException extends RuntimeException {
}
