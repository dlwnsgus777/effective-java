package me.whiteship.chapter05.item26.genericdao;

public interface Entity {

    Long getId();
}
