package me.whiteship.chapter04.item17.part3;

public class ComplexExample {

    public static void main(String[] args) {
        Complex complex = Complex.valueOf(1, 0.222);
    }
}
