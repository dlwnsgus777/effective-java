package me.whiteship.chapter04.item21;

public class SuperClass {

    private void hello() {
        System.out.println("hello class");
    }
}
