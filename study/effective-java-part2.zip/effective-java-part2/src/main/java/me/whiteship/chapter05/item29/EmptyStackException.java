package me.whiteship.chapter05.item29;

public class EmptyStackException extends RuntimeException {
}
