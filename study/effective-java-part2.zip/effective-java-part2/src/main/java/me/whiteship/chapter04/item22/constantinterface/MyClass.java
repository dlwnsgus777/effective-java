package me.whiteship.chapter04.item22.constantinterface;

public class MyClass implements PhysicalConstants {

    public static void main(String[] args) {
        System.out.println(BOLTZMANN_CONSTANT);
    }

}
