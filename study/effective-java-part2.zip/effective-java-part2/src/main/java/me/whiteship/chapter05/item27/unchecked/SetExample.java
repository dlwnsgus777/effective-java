package me.whiteship.chapter05.item27.unchecked;

import java.util.HashSet;
import java.util.Set;

public class SetExample {

    public static void main(String[] args) {
        Set names = new HashSet();

        Set<String> strings = new HashSet<>();
    }
}
