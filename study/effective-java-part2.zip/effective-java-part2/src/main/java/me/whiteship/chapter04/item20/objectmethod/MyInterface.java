package me.whiteship.chapter04.item20.objectmethod;

public interface MyInterface {

//    default String toString() {
//        return "myString";
//    }
//
//    default int hashCode() {
//        return 10;
//    }
//
//    default boolean equals(Object o) {
//        return true;
//    }

}
