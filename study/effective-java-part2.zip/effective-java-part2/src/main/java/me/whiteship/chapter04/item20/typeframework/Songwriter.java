package me.whiteship.chapter04.item20.typeframework;

public interface Songwriter {

    Song compose(int shartPosition);
}
