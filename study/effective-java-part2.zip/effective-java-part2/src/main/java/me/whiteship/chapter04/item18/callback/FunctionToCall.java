package me.whiteship.chapter04.item18.callback;

interface FunctionToCall {

    void call();

    void run();
}
