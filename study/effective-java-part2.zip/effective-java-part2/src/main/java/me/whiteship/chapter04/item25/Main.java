package me.whiteship.chapter04.item25;

// (150쪽)
public class Main {
    public static void main(String[] args) {
        System.out.println(Utensil.NAME + Dessert.NAME);
    }
}
